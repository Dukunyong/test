import React from 'react';

export default class FooterComponent extends React.Component {

	render() {
		return <div>footer</div>
	}


}